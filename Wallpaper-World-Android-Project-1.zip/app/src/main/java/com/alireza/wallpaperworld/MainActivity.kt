package com.alireza.wallpaperworld

import android.annotation.SuppressLint
import android.app.Activity
import android.app.WallpaperManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(WallpaperBridge(), "AndroidWallpaper")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class WallpaperBridge {
        @JavascriptInterface
        fun setWallpaper(url: String, target: String) {
            Executors.newSingleThreadExecutor().execute {
                try {
                    val connection = URL(url).openConnection() as HttpURLConnection
                    connection.connectTimeout = 20000
                    connection.readTimeout = 30000
                    connection.instanceFollowRedirects = true
                    connection.setRequestProperty("User-Agent", "WallpaperWorld/1.0")
                    connection.connect()
                    connection.inputStream.use { input ->
                        val bitmap = BitmapFactory.decodeStream(input) ?: return@execute
                        val manager = WallpaperManager.getInstance(this@MainActivity)
                        val flags = when (target) {
                            "home" -> WallpaperManager.FLAG_SYSTEM
                            "lock" -> WallpaperManager.FLAG_LOCK
                            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                        }
                        manager.setBitmap(bitmap, null, true, flags)
                    }
                    connection.disconnect()
                } catch (_: Exception) { }
            }
        }

        @JavascriptInterface
        fun scheduleAutoWallpaper(configJson: String) {
            try {
                val cfg = JSONObject(configJson)
                val prefs = getSharedPreferences("wallpaper_world", MODE_PRIVATE)
                val enabled = cfg.optBoolean("enabled", false)
                if (!enabled) {
                    WorkManager.getInstance(this@MainActivity)
                        .cancelUniqueWork(WallpaperWorker.WORK_NAME)
                    prefs.edit().putBoolean("enabled", false).apply()
                    return
                }

                val urls = cfg.optJSONArray("urls")
                val urlList = (0 until (urls?.length() ?: 0))
                    .mapNotNull { urls?.optString(it) }
                    .filter { it.startsWith("https://") }
                    .distinct()
                if (urlList.isNotEmpty()) {
                    prefs.edit().putString("urls", urlList.joinToString("\n")).apply()
                }
                prefs.edit()
                    .putBoolean("enabled", true)
                    .putString("target", cfg.optString("target", "both"))
                    .putString("source", cfg.optString("source", "current"))
                    .apply()

                val minutes = cfg.optLong("intervalMinutes", 60L).coerceAtLeast(15L)
                val wifiOnly = cfg.optBoolean("wifiOnly", false)
                val constraints = Constraints.Builder()
                    .setRequiredNetworkType(
                        if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
                    )
                    .build()
                val request = PeriodicWorkRequestBuilder<WallpaperWorker>(
                    minutes, TimeUnit.MINUTES
                ).setConstraints(constraints).build()

                WorkManager.getInstance(this@MainActivity).enqueueUniquePeriodicWork(
                    WallpaperWorker.WORK_NAME,
                    ExistingPeriodicWorkPolicy.UPDATE,
                    request
                )
            } catch (_: Exception) { }
        }
    }
}
