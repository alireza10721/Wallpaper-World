package com.alireza.wallpaperworld

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class WallpaperWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val ctx = applicationContext
        val prefs = ctx.getSharedPreferences("wallpaper_world", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return Result.success()

        val cacheDir = File(ctx.filesDir, "wallpaper_cache")
        val allCached = cacheDir.listFiles()?.filter { it.isFile && it.length() > 1024 && isImage(it) }.orEmpty()
        val requestedUrls = prefs.getString("urls", "").orEmpty().lines().filter { it.startsWith("https://") }
        val requestedNames = requestedUrls.map { url ->
            val hash = java.security.MessageDigest.getInstance("SHA-256").digest(url.toByteArray())
                .joinToString("") { "%02x".format(it) } + ".img"
            hash
        }.toSet()
        val selectedCached = if (requestedNames.isNotEmpty())
            allCached.filter { it.name in requestedNames } else allCached
        val cached = selectedCached.ifEmpty { allCached }
        val online = isOnline(ctx)
        val wifiOnly = prefs.getBoolean("wifi_only", false)
        val bitmap = try {
            if (cached.isNotEmpty()) {
                val previous = prefs.getString("last_file", "")
                val candidates = cached.filter { it.absolutePath != previous }.ifEmpty { cached }
                val file = candidates.random()
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) prefs.edit().putString("last_file", file.absolutePath).apply()
                bmp
            } else if (online && !wifiOnly) {
                downloadOne(prefs.getString("urls", "").orEmpty().lines().filter { it.startsWith("https://") }, prefs)
            } else null
        } catch (_: Exception) { null }

        if (bitmap == null) return if (online) Result.retry() else Result.success()

        return try {
            val target = prefs.getString("target", "both")
            val flags = when (target) {
                "home" -> WallpaperManager.FLAG_SYSTEM
                "lock" -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            WallpaperManager.getInstance(ctx).setBitmap(bitmap, null, true, flags)
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }

    private fun isImage(file: File): Boolean {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, options)
        return options.outWidth > 0 && options.outHeight > 0
    }

    private fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun downloadOne(urls: List<String>, prefs: android.content.SharedPreferences): android.graphics.Bitmap? {
        val previous = prefs.getString("last_url", "")
        val chosen = urls.filter { it != previous }.ifEmpty { urls }.shuffled().firstOrNull() ?: return null
        val c = URL(chosen).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 WallpaperWorld/2.0")
        val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
        c.disconnect()
        if (bmp != null) prefs.edit().putString("last_url", chosen).apply()
        return bmp
    }

    companion object { const val WORK_NAME = "wallpaper_world_periodic_change" }
}
