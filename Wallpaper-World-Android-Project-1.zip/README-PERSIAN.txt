Wallpaper World Android project
نسخه آزمایشی پروژه اندروید برای ساخت APK با GitHub Actions

محتویات:
- اپ اندروید WebView
- ارتباط JavaScript با قابلیت بومی تنظیم تصویر زمینه
- زمان‌بندی پس‌زمینه با Android WorkManager
- بازه حداقل ۱۵ دقیقه (زمان اجرا دقیق و تضمینی نیست)
- انتخاب صفحه اصلی، قفل یا هر دو
- محدودیت شبکه: اتصال معمولی یا شبکه غیرمصرفی (وای‌فای/Unmetered)

برای ساخت:
1) محتویات این ZIP را در پوشه‌ای با نام Wallpaper-World-Android-Project از حالت فشرده خارج کنید.
2) کل محتویات پوشه را در ریشه مخزن GitHub بارگذاری کنید.
3) فایل workflow را طبق متن راهنما در .github/workflows/android.yml بسازید.
4) در Actions اجرای workflow را مشاهده کنید و APK را از Artifacts دریافت کنید.

نکته: Android WorkManager زمان اجرا را به‌صورت تقریبی مدیریت می‌کند و ممکن است به‌دلیل Doze/باتری دیرتر اجرا شود.
