package com.alireza.wallpaperworld

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.net.HttpURLConnection
import java.net.URL

class WallpaperWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("wallpaper_world", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return Result.success()

        val urls = prefs.getString("urls", "").orEmpty()
            .lines().filter { it.startsWith("https://") }
        if (urls.isEmpty()) return Result.retry()

        val previous = prefs.getString("last_url", "")
        val candidates = urls.filter { it != previous }.ifEmpty { urls }
        val chosen = candidates.random()

        return try {
            val connection = URL(chosen).openConnection() as HttpURLConnection
            connection.connectTimeout = 20000
            connection.readTimeout = 30000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", "WallpaperWorld/1.0")
            connection.connect()
            val bitmap = connection.inputStream.use { BitmapFactory.decodeStream(it) }
            connection.disconnect()
            if (bitmap == null) return Result.retry()

            val target = prefs.getString("target", "both")
            val flags = when (target) {
                "home" -> WallpaperManager.FLAG_SYSTEM
                "lock" -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            WallpaperManager.getInstance(applicationContext).setBitmap(bitmap, null, true, flags)
            prefs.edit().putString("last_url", chosen).apply()
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "wallpaper_world_periodic_change"
    }
}
